import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "General Scope Contracting | Edmonton Contractor",
  description: "General Scope Contracting provides residential and commercial contracting services in Edmonton and surrounding areas.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
