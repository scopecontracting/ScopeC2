"use client";

import React from "react";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin, Hammer, ShieldCheck, Clock, CheckCircle2 } from "lucide-react";

export default function GeneralScopeContractingWebsite() {
  return (
    <div className="min-h-screen bg-neutral-950 text-white">
      <header className="sticky top-0 z-50 border-b border-white/10 bg-neutral-950/85 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="text-xl font-bold tracking-tight">General Scope Contracting</div>
          <nav className="hidden gap-8 text-sm text-neutral-300 md:flex">
            <a href="#services" className="hover:text-white">Services</a>
            <a href="#about" className="hover:text-white">About</a>
            <a href="#contact" className="hover:text-white">Contact</a>
          </nav>
          <a href="#contact" className="rounded-full bg-white px-5 py-2 text-sm font-semibold text-neutral-950 hover:bg-neutral-200">
            Get a Quote
          </a>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden px-6 py-24 md:py-32">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.14),transparent_35%)]" />
          <div className="relative mx-auto grid max-w-7xl items-center gap-12 md:grid-cols-2">
            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <p className="mb-4 inline-flex rounded-full border border-white/15 px-4 py-2 text-sm text-neutral-300">
                Edmonton Contracting Services
              </p>
              <h1 className="text-5xl font-bold leading-tight tracking-tight md:text-7xl">
                Quality work. Clear scope. Built right.
              </h1>
              <p className="mt-6 max-w-xl text-lg leading-8 text-neutral-300">
                General Scope Contracting provides reliable residential and commercial contracting services in Edmonton and surrounding areas. From repairs to renovations, we help bring your project from idea to completion.
              </p>
              <div className="mt-8 flex flex-col gap-4 sm:flex-row">
                <a href="#contact" className="rounded-full bg-white px-7 py-3 text-center font-semibold text-neutral-950 hover:bg-neutral-200">
                  Request a Free Quote
                </a>
                <a href="#services" className="rounded-full border border-white/20 px-7 py-3 text-center font-semibold text-white hover:bg-white/10">
                  View Services
                </a>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.6, delay: 0.15 }} className="rounded-[2rem] border border-white/10 bg-white/5 p-6 shadow-2xl">
              <div className="grid gap-4">
                {["Renovations", "Repairs", "Finishing", "Property Improvements"].map((item) => (
                  <div key={item} className="flex items-center gap-4 rounded-2xl bg-neutral-900 p-5">
                    <CheckCircle2 className="h-6 w-6" />
                    <span className="text-lg font-semibold">{item}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        <section id="services" className="border-t border-white/10 px-6 py-20">
          <div className="mx-auto max-w-7xl">
            <div className="mb-12 max-w-2xl">
              <h2 className="text-4xl font-bold tracking-tight">Services</h2>
              <p className="mt-4 text-neutral-300">Professional contracting support for homes, rentals, and commercial properties.</p>
            </div>
            <div className="grid gap-6 md:grid-cols-3">
              <ServiceCard icon={<Hammer />} title="Renovations" text="Interior upgrades, basement improvements, repairs, and general renovation work." />
              <ServiceCard icon={<ShieldCheck />} title="Reliable Workmanship" text="Clean, careful work with attention to detail and clear communication." />
              <ServiceCard icon={<Clock />} title="Project Support" text="Help with planning, estimating, scheduling, and completing the scope of work." />
            </div>
          </div>
        </section>

        <section id="about" className="bg-white px-6 py-20 text-neutral-950">
          <div className="mx-auto grid max-w-7xl gap-12 md:grid-cols-2">
            <div>
              <h2 className="text-4xl font-bold tracking-tight">About General Scope Contracting</h2>
              <p className="mt-6 text-lg leading-8 text-neutral-700">
                We focus on honest service, clean finishes, and straightforward project communication. Whether it is a small repair or a larger improvement, the goal is simple: make the work clear, organized, and done right.
              </p>
            </div>
            <div className="grid gap-4">
              <div className="rounded-3xl bg-neutral-100 p-6">
                <h3 className="text-xl font-bold">Clear Quotes</h3>
                <p className="mt-2 text-neutral-700">Know what is included before the project starts.</p>
              </div>
              <div className="rounded-3xl bg-neutral-100 p-6">
                <h3 className="text-xl font-bold">Local Service</h3>
                <p className="mt-2 text-neutral-700">Serving Edmonton and nearby communities.</p>
              </div>
            </div>
          </div>
        </section>

        <section id="contact" className="px-6 py-20">
          <div className="mx-auto max-w-4xl rounded-[2rem] border border-white/10 bg-white/5 p-8 md:p-12">
            <h2 className="text-4xl font-bold tracking-tight">Get a free quote</h2>
            <p className="mt-4 text-neutral-300">Tell us what you need done and we’ll get back to you.</p>

            <div className="mt-8 grid gap-4 text-neutral-200">
              <ContactRow icon={<Mail />} text="Scopecontracting1@outlook.com" />
              <ContactRow icon={<MapPin />} text="906 Crystallina Nera Way, Edmonton, AB T5Z 0L1" />
              <ContactRow icon={<Phone />} text="Add your phone number here" />
            </div>

            <form className="mt-10 grid gap-4">
              <input className="rounded-2xl border border-white/10 bg-neutral-900 px-5 py-4 outline-none placeholder:text-neutral-500" placeholder="Name" />
              <input className="rounded-2xl border border-white/10 bg-neutral-900 px-5 py-4 outline-none placeholder:text-neutral-500" placeholder="Email or phone" />
              <textarea className="min-h-36 rounded-2xl border border-white/10 bg-neutral-900 px-5 py-4 outline-none placeholder:text-neutral-500" placeholder="Tell us about your project" />
              <button type="button" className="rounded-full bg-white px-7 py-4 font-semibold text-neutral-950 hover:bg-neutral-200">
                Submit Request
              </button>
            </form>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/10 px-6 py-8 text-center text-sm text-neutral-400">
        © 2026 General Scope Contracting. All rights reserved.
      </footer>
    </div>
  );
}

function ServiceCard({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return (
    <div className="rounded-[2rem] border border-white/10 bg-white/5 p-8 shadow-xl">
      <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-neutral-950">
        {icon}
      </div>
      <h3 className="text-2xl font-bold">{title}</h3>
      <p className="mt-4 leading-7 text-neutral-300">{text}</p>
    </div>
  );
}

function ContactRow({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="text-white">{icon}</span>
      <span>{text}</span>
    </div>
  );
}
